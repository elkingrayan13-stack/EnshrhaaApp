package com.inshrha.app
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{EnshrhaScreen{share()}}}private fun share(){val i=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,"منشور من تطبيق انشرها")};startActivity(Intent.createChooser(i,"انشر إلى"))}}
@Composable fun EnshrhaScreen(onShare:()->Unit){var text by remember{mutableStateOf("")};var wa by remember{mutableStateOf(true)};var fb by remember{mutableStateOf(true)};var tg by remember{mutableStateOf(true)};var imo by remember{mutableStateOf(true)};CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl){Scaffold(bottomBar={NavigationBar{NavigationBarItem(true,{},icon={Text("🏠")},label={Text("الرئيسية")});NavigationBarItem(false,{},icon={Text("📝")},label={Text("المنشورات")});NavigationBarItem(false,{},icon={Text("👤")},label={Text("حساباتي")});NavigationBarItem(false,{},icon={Text("⚙️")},label={Text("الإعدادات")})}}){p->Column(Modifier.fillMaxSize().padding(p).verticalScroll(rememberScrollState()).background(Brush.verticalGradient(listOf(MaterialTheme.colorScheme.primary.copy(.08f),MaterialTheme.colorScheme.background))).padding(16.dp)){Text("📣 انشرها",fontSize=30.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);Text("من مكان واحد… لجميع منصاتك",fontSize=15.sp);Spacer(Modifier.height(18.dp));Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("اكتب منشورك هنا...",fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));OutlinedTextField(text,{text=it},Modifier.fillMaxWidth().height(150.dp),placeholder={Text("اكتب النص الذي تريد مشاركته")});Spacer(Modifier.height(12.dp));Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton({}){Text("🖼️ صورة")};OutlinedButton({}){Text("🎥 فيديو")};OutlinedButton({}){Text("🔗 رابط")}}}};Spacer(Modifier.height(16.dp));Text("اختر المنصات",fontWeight=FontWeight.Bold,fontSize=19.sp);PlatformSwitch("WhatsApp Status",wa){wa=it};PlatformSwitch("Facebook Story",fb){fb=it};PlatformSwitch("Telegram Story",tg){tg=it};PlatformSwitch("imo",imo){imo=it};Spacer(Modifier.height(12.dp));Button(onShare,Modifier.fillMaxWidth().height(54.dp)){Text("🚀 انشر الآن",fontSize=18.sp,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(12.dp));Text("ملاحظة: يفتح Android شاشة المشاركة الرسمية، وقد تحتاج لتأكيد النشر داخل كل منصة.",fontSize=12.sp,textAlign=TextAlign.Center)}}}}
@Composable fun PlatformSwitch(name:String,checked:Boolean,onChange:(Boolean)->Unit){Card(Modifier.fillMaxWidth().padding(vertical=3.dp)){Row(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically){Text(name,Modifier.weight(1f),fontSize=16.sp);Switch(checked,onChange)}}}
