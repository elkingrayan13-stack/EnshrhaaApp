# انشرها — EnshrhaaApp

تطبيق Android بسيط لمشاركة المنشورات إلى التطبيقات المثبتة على الهاتف.

## البناء

```bash
./gradlew assembleDebug
```

الـ APK الناتج:
`app/build/outputs/apk/debug/app-debug.apk`

## ملاحظات
- التطبيق يستخدم Android Sharesheet/Intents ولا يستطيع النشر الصامت داخل Facebook أو WhatsApp أو Telegram بدون واجهات API وصلاحيات رسمية.
- اختيارات المنصات تحدد التطبيقات المستهدفة عند الضغط على «انشر الآن».
- الـ GitHub Actions يبني المشروع مباشرة ولا يحتاج إلى رفع ZIP داخل المستودع.
